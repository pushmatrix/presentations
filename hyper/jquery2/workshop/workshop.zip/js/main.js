$(document).ready(function() {

  /////////
  // EXERCISE 1

  /////////
  // EXERCISE 2


  /////////
  // EXERCISE 3



});
