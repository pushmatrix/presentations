$(document).ready(function() {

  //////////////
  // EXERCISE 2
  // Add your code below here so that an alert message pops up when you press that button

  //////////////
  // EXERCISE 3

  /// "Fade out" spell

  /// "Fade in" spell

  // "Transformation" spell

  // "Hover" spell

  //////////////
  // EXERCISE 4

  //////////////
  // EXERCISE 5
  $('#add-to-cart').click(addToCart);
  var numItems = 0;
  function addToCart() {
    console.log("added an item!");
  }



});
